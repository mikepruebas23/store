import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suscriptor',
  templateUrl: './suscriptor.component.html',
  styleUrls: ['./suscriptor.component.scss']
})
export class SuscriptorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
