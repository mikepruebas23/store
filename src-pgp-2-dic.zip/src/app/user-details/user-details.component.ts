import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth/services/auth.service';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent implements OnInit {

  UID: string = this._ActivatedRoute.snapshot.params.id;
  POS: string = this._ActivatedRoute.snapshot.params.pos;
  userData: any;

  user = { 
    displayName: "",
    email: "",
    emailVerified: true,
    main: "",
    position: this.POS,
    rnkPoints: 0,
    role: "SUSCRIPTOR",
    photoURL: '',
    secondary: "",
    switchCode: "",
    state:"",
    tagName: "",
    uid: this.UID,
  }
  
  constructor(
    private _ActivatedRoute: ActivatedRoute,
    private _AuthService: AuthService
    ) { }

  ngOnInit() {
    this._AuthService.getUsers2(this.UID).valueChanges().subscribe(
      res => { 
        // console.log('RES: ', res);
        this.user.displayName = res.displayName,
        this.user.tagName = res.tagName,
        this.user.main = res.main,
        this.user.secondary = res.secondary,
        this.user.state = res.state,
        this.user.switchCode = res.switchCode,
        this.user.rnkPoints = res.rnkPoints,
        this.user.photoURL = res.photoURL
      });
  }

}
