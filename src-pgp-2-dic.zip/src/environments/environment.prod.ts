export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBsMoyT2r4Q5rjv83eNXMWkjw-SY2FpLDI",
    authDomain: "webappsmashranking.firebaseapp.com",
    databaseURL: "https://webappsmashranking.firebaseio.com",
    projectId: "webappsmashranking",
    storageBucket: "webappsmashranking.appspot.com",
    messagingSenderId: "453466420604",
    appId: "1:453466420604:web:29bee6dbc79d3b815fa0f9"
  }
};
